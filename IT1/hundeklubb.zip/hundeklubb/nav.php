<!DOCTYPE html>
<html>
<!-- seksjon for metainfo -->

<head>
    <title>Oversikt</title>
    <meta charset="utf-8" />
    <link rel="stylesheet" type="text/css" media="screen" href="stilarkfil.css" />
    <link rel="stylesheet" type="text/css" media="print" href="utskrift.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">



</head>


<body>

    <nav>
        <ul>

            <li><a href="index.php">Hjem</a></li>
            <li><a href="hundeeiere.php">Hundeeire</a>
                <li><a href="leggtilmedlem.php">Legg til medlem</a></li>
                <li><a href="leggtilhund.php">Legg til hund</a></li>
                <li><a href="personadministrasjon.php">Oppdater medlemskap</a></li>
                <li><a href="soek.php">Søk</a></li>


        </ul>
    </nav>

</body>

</html>
