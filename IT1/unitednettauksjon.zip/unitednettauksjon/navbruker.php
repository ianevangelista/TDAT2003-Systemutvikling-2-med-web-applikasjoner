<!DOCTYPE html>
<html>
<!-- seksjon for metainfo -->

<head>
    <title>Oversikt</title>
    <meta charset="utf-8" />
    <link rel="stylesheet" type="text/css" media="screen" href="stilarkfilcss.css" />
    <link rel="stylesheet" type="text/css" media="print" href="utskrift.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">



</head>


<body>

    <nav>
        <ul>

            <li><a href="index.php">Hjem</a></li>
            <li><a href="admin.php">Se som admin</a></li>
            <li><a href="bruker.php">Se som bruker</a></li>
            <li><a href="bruker.php">Kategori ￬</a>
                <ul>
                    <li><a href="kategoridrakt.php">Drakt</a></li>
                    <li><a href="kategoriball.php">Ball</a></li>
                    <li><a href="kategorisko.php">Sko</a></li>
                </ul>
            </li>
            <li><a href="alleauksjoner.php">Alle auksjoner</a></li>
            <li><a href="registrerbruker.php">Registrer deg</a></li>
            <li><a href="brukeradmin.php">Oppdater bruker</a></li>



        </ul>
    </nav>

</body>

</html>
