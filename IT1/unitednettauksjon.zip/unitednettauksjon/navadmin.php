<!DOCTYPE html>
<html>
<!-- seksjon for metainfo -->

<head>
    <title>Oversikt</title>
    <meta charset="utf-8" />
    <link rel="stylesheet" type="text/css" media="screen" href="stilarkfilcss.css" />
    <link rel="stylesheet" type="text/css" media="print" href="utskrift.css" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">



</head>


<body>

      <nav>
        <ul>

            <li><a href="index.php">Hjem</a></li>
            <li><a href="admin.php">Se som admin</a></li>
            <li><a href="bruker.php">Se som bruker</a></li>
            <li><a href="bruker.php">Oversikt ￬</a>
                <ul>
                    <li><a href="oversiktbrukere.php">Brukere</a></li>
                    <li><a href="solgt.php">Solgt</a></li>
                    <li><a href="utgaatt.php">Utgått</a></li>
                </ul>
            </li>
            <li><a href="registreregjenstand.php">Registrere gjenstand</a></li>



        </ul>
    </nav>

</body>

</html>
